(() => {
  'use strict';
  const form = document.getElementById('missionForm');
  if (!form) return;
  const field = name => form.querySelector(`[name="${name}"]`);
  const parse = text => { const data=[];let row=[],value='',quoted=false;const push=()=>{row.push(value);if(row.some(Boolean)&&!String(row[0]).startsWith('#'))data.push(row);row=[];value=''};for(let i=0;i<text.length;i++){const char=text[i],next=text[i+1];if(quoted&&char==='"'&&next==='"'){value+='"';i++;}else if(char==='"')quoted=!quoted;else if(!quoted&&char===';'){row.push(value);value='';}else if(!quoted&&(char==='\n'||char==='\r')){if(char==='\r'&&next==='\n')i++;push();}else value+=char;}if(value||row.length)push();const head=data.shift()||[];return data.map(values=>Object.fromEntries(head.map((name,index)=>[String(name).replace(/^\uFEFF/,'').trim(),values[index]||'']))); };
  const apply = record => { Object.entries(record).forEach(([key, value]) => { const input = field(key); if (input && value !== '') input.value = value; }); form.dispatchEvent(new Event('change', { bubbles: true })); };
  const nextNumber = records => { const input = field('missionId'); if (!input || (input.value && !/-001$/.test(input.value))) return; const prefix = input.value?.split('-')[0] || (field('service') ? 'HEMS' : 'GAAR'); const values = records.map(row => Number((row.missionId || '').match(/(\d+)$/)?.[1] || 0)); input.value = `${prefix}-${String(Math.max(0, ...values) + 1).padStart(3, '0')}`; };
  const chooseLedger = () => { const picker = document.createElement('input'); picker.type = 'file'; picker.accept = '.csv,text/csv'; picker.onchange = () => { const file = picker.files[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => { const records = parse(reader.result); nextNumber(records); const choices = records.map((record, i) => `${i + 1}. ${record.missionId || '—'} — ${record.date || ''} — ${record.missionType || ''}`).join('\n'); const selected = Number(prompt(`Choisir une mission à charger :\n${choices}`, '1')); if (selected >= 1 && selected <= records.length) apply(records[selected - 1]); }; reader.readAsText(file); }; picker.click(); };
  const controls = document.querySelector('.controls .row');
  if (controls) { const button = document.createElement('button'); button.type = 'button'; button.className = 'secondary'; button.textContent = 'Charger depuis le registre'; button.onclick = chooseLedger; controls.append(button); }
  window.addEventListener('mission-ledger-autoload', event => { const records = parse(event.detail.text); nextNumber(records); });
})();
